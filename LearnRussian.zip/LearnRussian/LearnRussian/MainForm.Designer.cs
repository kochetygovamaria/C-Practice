﻿namespace LearnRussian
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Listen = new System.Windows.Forms.Button();
            this.Write = new System.Windows.Forms.Button();
            this.Readbutton = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(247)))), ((int)(((byte)(248)))));
            this.panel1.Location = new System.Drawing.Point(2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(703, 154);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(142)))), ((int)(((byte)(254)))));
            this.panel2.Controls.Add(this.Listen);
            this.panel2.Controls.Add(this.Write);
            this.panel2.Controls.Add(this.Readbutton);
            this.panel2.Location = new System.Drawing.Point(2, 151);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(703, 167);
            this.panel2.TabIndex = 1;
            // 
            // Listen
            // 
            this.Listen.Location = new System.Drawing.Point(452, 60);
            this.Listen.Name = "Listen";
            this.Listen.Size = new System.Drawing.Size(130, 48);
            this.Listen.TabIndex = 2;
            this.Listen.Text = "Listen";
            this.Listen.UseVisualStyleBackColor = true;
            // 
            // Write
            // 
            this.Write.Location = new System.Drawing.Point(269, 60);
            this.Write.Name = "Write";
            this.Write.Size = new System.Drawing.Size(130, 48);
            this.Write.TabIndex = 1;
            this.Write.Text = "Write";
            this.Write.UseVisualStyleBackColor = true;
            // 
            // Readbutton
            // 
            this.Readbutton.Location = new System.Drawing.Point(86, 60);
            this.Readbutton.Name = "Readbutton";
            this.Readbutton.Size = new System.Drawing.Size(130, 48);
            this.Readbutton.TabIndex = 0;
            this.Readbutton.Text = "Read";
            this.Readbutton.UseVisualStyleBackColor = true;
            this.Readbutton.Click += new System.EventHandler(this.Readbutton_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(84)))), ((int)(((byte)(80)))));
            this.panel3.Location = new System.Drawing.Point(2, 315);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(703, 177);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 493);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button Listen;
        private System.Windows.Forms.Button Write;
        private System.Windows.Forms.Button Readbutton;
    }
}