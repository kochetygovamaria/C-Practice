﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LearnRussian
{
    public partial class MainForm : Form
    {
        internal String UserName;
         List<Users> users;

        public MainForm()
        {
            InitializeComponent();
        }

        public MainForm(List<Users> users, string userName)
        {
            InitializeComponent();
            this.users = new List<Users>(users);
            this.UserName = userName;
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Readbutton_Click(object sender, EventArgs e)
        {
            ReadForm read = new ReadForm(users, UserName);
            this.Hide();
            read.ShowDialog();
            
        }
    }
}
