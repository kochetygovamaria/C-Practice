﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LearnRussian
{
    public partial class ReadForm : Form
    {
        internal String UserName;
        List<Users> users;
        public ReadForm(List<Users> users, string userName)
        {
            InitializeComponent();
            this.users = new List<Users>(users);
            this.UserName = userName;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MainForm main = new MainForm(users, UserName);
            this.Hide();
            main.ShowDialog();
           

        }

        private void ReadForm_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            ShortStoriesForm shortStory = new ShortStoriesForm(users, UserName);
            this.Hide();
            shortStory.ShowDialog();
        }
    }
}
