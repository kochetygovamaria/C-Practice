﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace LearnRussian
{
    public partial class ShortStoriesForm : Form
    {
        public ShortStoriesForm(List<Users> users, string userName)
        {
            InitializeComponent();
            this.userName = userName;
            this.users = new List<Users>(users);
        }
        internal String userName;
        List<Users> users;

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void ShortStoriesForm_Load(object sender, EventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("LoginUsers.xml");

            dataGridView1.DataSource = doc;

           
            XmlNodeList nodeList = doc.DocumentElement.SelectNodes("/ShortStories/Story");

            foreach (XmlNode node in nodeList)
            {
                
                    AuthorName.Text = node.SelectSingleNode("Author").InnerText;
                    Name.Text = node.SelectSingleNode("Name").InnerText;
                    Level.Text = node.SelectSingleNode("Level").InnerText;
                    numberPage.Text = node.SelectSingleNode("Pages").InnerText;
                  
                
            }


        }
        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {

          
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                AuthorName.Text = row.Cells[0].Value.ToString();
                Name.Text = row.Cells[1].Value.ToString();
                Level.Text = row.Cells[2].Value.ToString();
               numberPage.Text = row.Cells[3].Value.ToString();
               

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ReadForm read = new ReadForm(users, userName);
            this.Close();
            read.ShowDialog();
        }

        private void Name_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
