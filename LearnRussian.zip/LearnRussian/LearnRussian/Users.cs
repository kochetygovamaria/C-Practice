﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LearnRussian
{
    public class Users
    {
        public String UserName { get; set; }
        public String Password { get; set; }

        public Users() { }

        public void addUsers(string userName, string password)
        {
            this.UserName = userName;
            this.Password = password;
        }
    }
}