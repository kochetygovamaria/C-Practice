﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project
{
    public class Booking
    {
        String Carrier { get; set; }
        String From { get; set; }
        String To { get; set; }
        DateTime date { get; set; }
        double Price { get; set; }
        String Class { get; set; }

        public Booking() { }
        
        public void addBooking(string carrier,string from, string to,DateTime Date, double price, string Class)
        {
            this.Carrier = carrier;
            this.From = from;
            this.To = to;
            this.date = Date;
            this.Price = price;
            this.Class = Class;
        }

    }
}
