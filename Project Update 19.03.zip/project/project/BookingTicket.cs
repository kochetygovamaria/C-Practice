﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace project
{
    public partial class BookingTicket : Form
    {
        internal Form2 form2;
        public BookingTicket()
        {
            InitializeComponent();
        }

        private void BookingTicket_Load(object sender, EventArgs e)
        {
            LoadDataGrid();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void LoadDataGrid()
        {
            DataSet dataSet = new DataSet();
            dataSet.ReadXml("BookInfo.xml");
            dataGridView1.DataSource = dataSet.Tables[0];
            
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Bookbtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Not ready yet");
        }
    }
    }

