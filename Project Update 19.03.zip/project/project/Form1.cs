﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Person> persons = new List<Person>();
        List<Users> users = new List<Users>();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateAccount create = new CreateAccount();
            create.form1 = this;
            create.ShowDialog();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           

        }

        private void SingINbt_Click(object sender, EventArgs e)
        {



            XmlDocument doc = new XmlDocument();
            doc.Load("UserInfo.xml");

            foreach (XmlNode node in doc.SelectNodes("//UserInfo"))
            {

                String userName = node.SelectSingleNode("UserName").InnerText;
                String password = node.SelectSingleNode("Password").InnerText;

                if (userName == UserID.Text || password == PasswordID.Text)
                {

                    Form2 fmst = new Form2(persons, users, userName);

                    MessageBox.Show("Welcome");
                fmst.Show();
                this.Hide();
                    
                }
                

                }
           
           
          

            }

        }

       }
       
            
        
    
