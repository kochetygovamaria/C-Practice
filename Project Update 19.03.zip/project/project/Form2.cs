﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class Form2 : Form
    {
        BindingList<Person>Persons;
        BindingList<Users> users;

        internal String UserName;

        public Form2(List<Person>persons, List<Users>users,string UN)
        {
            InitializeComponent();
            this.Persons = new BindingList<Person>(persons);
            this.users = new BindingList<Users>(users);
            this.UserName = UN;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
           
        }

        private void myAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void viewToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           ViewForm view = new ViewForm(UserName);
            view.form2 = this;
            view.ShowDialog();
        }

        private void personalInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateInfo upInfo = new UpdateInfo(UserName);
            upInfo.form2= this;
            upInfo.ShowDialog();
        }

        private void passwordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdatePassword up = new UpdatePassword(UserName);
            up.form2 = this;
            up.ShowDialog();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void bookToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookingTicket bI = new BookingTicket();
            bI.form2=this;
            bI.ShowDialog();
        }

        private void contactToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Not ready yet");
        }

        private void myTripsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void viewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Not ready yet");
        }

        private void updateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Not ready yet");
        }

        private void deleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }
    }
}
