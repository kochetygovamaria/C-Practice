﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace project
{
    public partial class UpdateInfo : Form
    {
        internal Form2 form2;
        internal String userName;

        public UpdateInfo(String UN)
        {
            InitializeComponent();
            this.userName = UN;
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            XmlDocument xml1 = new XmlDocument();

            xml1.Load("UserInfo.xml");
            XmlNodeList nodes = xml1.SelectNodes("//UserInfo");

            foreach (XmlElement element in nodes)
            { 
              
                String firstName = element.SelectSingleNode("FirstName").InnerText;
                String lastName = element.SelectSingleNode("LastName").InnerText;
                String nationality = element.SelectSingleNode("Nationality").InnerText;
                String address = element.SelectSingleNode("Address").InnerText;
                String passport = element.SelectSingleNode("Passport").InnerText;
                String phone = element.SelectSingleNode("phone").InnerText;
                String dateOfBirth = element.SelectSingleNode("DateOfBirth").InnerText;
                String userName = element.SelectSingleNode("UserName").InnerText;

                    if (userName == UserName.Text && dateOfBirth == DateOfBirth.Text)
                    {
                        element.SelectSingleNode("FirstName").InnerText = FirstName.Text;
                        element.SelectSingleNode("LastName").InnerText = LastName.Text;
                        element.SelectSingleNode("Nationality").InnerText = Nationality.Text;
                        element.SelectSingleNode("Address").InnerText = Address.Text;
                        element.SelectSingleNode("Passport").InnerText = Passport.Text;
                        element.SelectSingleNode("phone").InnerText = Phone.Text;
                        xml1.Save("UserInfo.xml");
                        MessageBox.Show("You updated your information. Thank you");
                        this.Close();

                    }
               
                }
            }
        

        private void Passport_TextChanged(object sender, EventArgs e)
        {

        }

        private void UpdateInfo_Load(object sender, EventArgs e)
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("UserInfo.xml");
            XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("/UsersInfo/UserInfo");

            foreach (XmlNode node in nodeList)
            {
                if (node.SelectSingleNode("UserName").InnerText == userName)
                {
                    UserName.Text = node.SelectSingleNode("UserName").InnerText;
                    FirstName.Text = node.SelectSingleNode("FirstName").InnerText;
                    LastName.Text = node.SelectSingleNode("LastName").InnerText;
                    DateOfBirth.Text = node.SelectSingleNode("DateOfBirth").InnerText;
                    Nationality.Text = node.SelectSingleNode("Nationality").InnerText;
                    Passport.Text = node.SelectSingleNode("Passport").InnerText;
                    Address.Text = node.SelectSingleNode("Address").InnerText;
                    Phone.Text = node.SelectSingleNode("phone").InnerText;
                }
            }
        }
        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}