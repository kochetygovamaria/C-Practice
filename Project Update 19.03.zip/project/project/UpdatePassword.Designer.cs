﻿namespace project
{
    partial class UpdatePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdatePassword));
            this.currentPassword = new System.Windows.Forms.TextBox();
            this.NewPassword = new System.Windows.Forms.TextBox();
            this.ConfirmPassword = new System.Windows.Forms.TextBox();
            this.Current = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.confirm = new System.Windows.Forms.Label();
            this.Save = new System.Windows.Forms.Button();
            this.UserName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // currentPassword
            // 
            this.currentPassword.Location = new System.Drawing.Point(194, 123);
            this.currentPassword.Name = "currentPassword";
            this.currentPassword.Size = new System.Drawing.Size(142, 20);
            this.currentPassword.TabIndex = 0;
            // 
            // NewPassword
            // 
            this.NewPassword.Location = new System.Drawing.Point(194, 164);
            this.NewPassword.Name = "NewPassword";
            this.NewPassword.Size = new System.Drawing.Size(142, 20);
            this.NewPassword.TabIndex = 1;
            // 
            // ConfirmPassword
            // 
            this.ConfirmPassword.Location = new System.Drawing.Point(194, 203);
            this.ConfirmPassword.Name = "ConfirmPassword";
            this.ConfirmPassword.Size = new System.Drawing.Size(142, 20);
            this.ConfirmPassword.TabIndex = 2;
            // 
            // Current
            // 
            this.Current.BackColor = System.Drawing.Color.Transparent;
            this.Current.Location = new System.Drawing.Point(73, 123);
            this.Current.Margin = new System.Windows.Forms.Padding(3);
            this.Current.Name = "Current";
            this.Current.Padding = new System.Windows.Forms.Padding(3);
            this.Current.Size = new System.Drawing.Size(100, 23);
            this.Current.TabIndex = 3;
            this.Current.Text = "Current Password";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(73, 161);
            this.label1.Margin = new System.Windows.Forms.Padding(3);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(3);
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "New Password";
            // 
            // confirm
            // 
            this.confirm.BackColor = System.Drawing.Color.Transparent;
            this.confirm.Location = new System.Drawing.Point(73, 203);
            this.confirm.Margin = new System.Windows.Forms.Padding(3);
            this.confirm.Name = "confirm";
            this.confirm.Padding = new System.Windows.Forms.Padding(3);
            this.confirm.Size = new System.Drawing.Size(100, 23);
            this.confirm.TabIndex = 5;
            this.confirm.Text = "Confirm Password";
            // 
            // Save
            // 
            this.Save.BackColor = System.Drawing.Color.Transparent;
            this.Save.Location = new System.Drawing.Point(211, 259);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(106, 26);
            this.Save.TabIndex = 6;
            this.Save.Text = "Save";
            this.Save.UseVisualStyleBackColor = false;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // UserName
            // 
            this.UserName.Location = new System.Drawing.Point(194, 87);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(142, 20);
            this.UserName.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(73, 84);
            this.label2.Margin = new System.Windows.Forms.Padding(3);
            this.label2.Name = "label2";
            this.label2.Padding = new System.Windows.Forms.Padding(3);
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 8;
            this.label2.Text = "User Name";
            // 
            // UpdatePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(506, 357);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.UserName);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.confirm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Current);
            this.Controls.Add(this.ConfirmPassword);
            this.Controls.Add(this.NewPassword);
            this.Controls.Add(this.currentPassword);
            this.Name = "UpdatePassword";
            this.Text = "Update Password";
            this.Load += new System.EventHandler(this.UpdatePassword_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox currentPassword;
        private System.Windows.Forms.TextBox NewPassword;
        private System.Windows.Forms.TextBox ConfirmPassword;
        private System.Windows.Forms.Label Current;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label confirm;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.TextBox UserName;
        private System.Windows.Forms.Label label2;
    }
}