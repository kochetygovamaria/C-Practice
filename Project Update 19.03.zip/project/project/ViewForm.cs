﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace project
{
    public partial class ViewForm : Form
    {

        internal Form2 form2;
        internal Form1 form1;
        internal String UserName;


        public ViewForm(String UN)
        {
            InitializeComponent();
            this.users = new BindingList<Users>();
            this.UserName = UN;

        }
        BindingList<Person> persons;
        BindingList<Users> users;
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void ViewForm_Load(object sender, EventArgs e)
        {


                XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("UserInfo.xml");
            XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("/UsersInfo/UserInfo");

            foreach (XmlNode node in nodeList)
            {
                if (node.SelectSingleNode("UserName").InnerText == UserName)
                {
                    FirstName.Text = node.SelectSingleNode("FirstName").InnerText;
                    LastName.Text = node.SelectSingleNode("LastName").InnerText;
                    DateOfBirth.Text = node.SelectSingleNode("DateOfBirth").InnerText;
                    Nationality.Text = node.SelectSingleNode("Nationality").InnerText;
                    Passport.Text = node.SelectSingleNode("Passport").InnerText;
                    Address.Text = node.SelectSingleNode("Address").InnerText;
                    Phone.Text = node.SelectSingleNode("phone").InnerText;
                }
               
                
            }
        }

        private void Backbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}