﻿namespace project
{
    partial class CreateAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CreateAccount));
            this.FirstName = new System.Windows.Forms.TextBox();
            this.LastName = new System.Windows.Forms.TextBox();
            this.DateOfBirth = new System.Windows.Forms.TextBox();
            this.Nationality = new System.Windows.Forms.TextBox();
            this.Passport = new System.Windows.Forms.TextBox();
            this.Address = new System.Windows.Forms.TextBox();
            this.FirstN = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Phone = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.UserName = new System.Windows.Forms.TextBox();
            this.Register = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(219, 39);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(156, 20);
            this.FirstName.TabIndex = 0;
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(219, 80);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(156, 20);
            this.LastName.TabIndex = 1;
            // 
            // DateOfBirth
            // 
            this.DateOfBirth.Location = new System.Drawing.Point(219, 122);
            this.DateOfBirth.Name = "DateOfBirth";
            this.DateOfBirth.Size = new System.Drawing.Size(156, 20);
            this.DateOfBirth.TabIndex = 2;
            // 
            // Nationality
            // 
            this.Nationality.Location = new System.Drawing.Point(219, 164);
            this.Nationality.Name = "Nationality";
            this.Nationality.Size = new System.Drawing.Size(156, 20);
            this.Nationality.TabIndex = 3;
            // 
            // Passport
            // 
            this.Passport.Location = new System.Drawing.Point(219, 205);
            this.Passport.Name = "Passport";
            this.Passport.Size = new System.Drawing.Size(156, 20);
            this.Passport.TabIndex = 4;
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(219, 242);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(156, 20);
            this.Address.TabIndex = 5;
            // 
            // FirstN
            // 
            this.FirstN.Location = new System.Drawing.Point(94, 39);
            this.FirstN.Name = "FirstN";
            this.FirstN.Size = new System.Drawing.Size(100, 20);
            this.FirstN.TabIndex = 6;
            this.FirstN.Text = "First Name";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(94, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Last Name";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(94, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Date Of Birth";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(94, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Nationality";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(94, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Passoprt Number";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(94, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Address";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(94, 282);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "Phone";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(425, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "UserName";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(425, 83);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Password";
            // 
            // Phone
            // 
            this.Phone.Location = new System.Drawing.Point(219, 279);
            this.Phone.Name = "Phone";
            this.Phone.Size = new System.Drawing.Size(156, 20);
            this.Phone.TabIndex = 15;
            // 
            // Password
            // 
            this.Password.Location = new System.Drawing.Point(553, 80);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(156, 20);
            this.Password.TabIndex = 16;
            // 
            // UserName
            // 
            this.UserName.Location = new System.Drawing.Point(553, 42);
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(156, 20);
            this.UserName.TabIndex = 17;
            // 
            // Register
            // 
            this.Register.Location = new System.Drawing.Point(372, 336);
            this.Register.Name = "Register";
            this.Register.Size = new System.Drawing.Size(75, 23);
            this.Register.TabIndex = 18;
            this.Register.Text = "Sign Up";
            this.Register.UseVisualStyleBackColor = true;
            this.Register.Click += new System.EventHandler(this.Register_Click);
            // 
            // CreateAccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.Register);
            this.Controls.Add(this.UserName);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Phone);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FirstN);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.Passport);
            this.Controls.Add(this.Nationality);
            this.Controls.Add(this.DateOfBirth);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.FirstName);
            this.Name = "CreateAccount";
            this.Text = "CreateAccount";
            this.Load += new System.EventHandler(this.CreateAccount_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox DateOfBirth;
        private System.Windows.Forms.TextBox Nationality;
        private System.Windows.Forms.TextBox Passport;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.Label FirstN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Phone;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.TextBox UserName;
        private System.Windows.Forms.Button Register;
    }
}