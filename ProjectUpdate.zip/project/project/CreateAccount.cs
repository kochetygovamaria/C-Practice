﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class CreateAccount : Form
    {
       internal Form1 form1;
        BindingList<Users> users;
       // List<Users> users = new List<Users>();
        public CreateAccount()
        {
            InitializeComponent();
            this.users = new BindingList<Users>();
        }

        private void CreateAccount_Load(object sender, EventArgs e)
        {
            users = Helper.LoadUsers("UserInfo.xml");
        }

        private void Register_Click(object sender, EventArgs e)
        {
            if (FirstName.Text.Trim() != "" && LastName.Text.Trim() != " " && DateOfBirth.Text.Trim() != "" && Nationality.Text.Trim() != " " && Passport.Text.Trim() != "" && Address.Text.Trim() != "" && Phone.Text.Trim() != "" && UserName.Text.Trim() != "" && Password.Text.Trim() != "")
            {
                Users user = new Users();
                double phone = Convert.ToDouble(Phone.Text);
                DateTime dayOfBirth = Convert.ToDateTime(DateOfBirth.Text);
                String access = "User";
                user.addUser(UserName.Text, Password.Text, FirstName.Text, LastName.Text, dayOfBirth, Nationality.Text, Passport.Text, Address.Text, phone, access);
                users.Add(user);
                Helper.addUser(new List<Users>(users));

                this.Close();
            }
        }
    }
}