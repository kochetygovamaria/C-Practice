﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace project
{
    public partial class Form2 : Form
    {
        BindingList<Person>Persons;
        BindingList<Users> users;

        public Form2(List<Person>persons, List<Users>users)
        {
            InitializeComponent();
            this.Persons = new BindingList<Person>(persons);
            this.users = new BindingList<Users>(users);
        }

        private void Form2_Load(object sender, EventArgs e)
        {
           
        }

        private void myAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void viewToolStripMenuItem1_Click(object sender, EventArgs e)
        {
           ViewForm view = new ViewForm();
            view.form2 = this;
            view.ShowDialog();
        }

        private void personalInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateInfo upInfo = new UpdateInfo();
            upInfo.form2= this;
            upInfo.ShowDialog();
        }

        private void passwordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdatePassword up = new UpdatePassword();
            up.form2 = this;
            up.ShowDialog();
        }
    }
}
