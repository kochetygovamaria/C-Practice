﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace project
{
    public partial class UpdatePassword : Form
    {
        internal Form2 form2;
        
        public UpdatePassword()
        {
            InitializeComponent();
        }

        private void UpdatePassword_Load(object sender, EventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {
            XmlDocument xml1 = new XmlDocument();

            xml1.Load("UserInfo.xml");

            XmlNodeList nodes = xml1.SelectNodes("//UserInfo");
            foreach (XmlElement element in nodes)
            {
                String password = element.SelectSingleNode("Password").InnerText;
                String userName = element.SelectSingleNode("UserName").InnerText;
                if (userName==UserName.Text && password==currentPassword.Text && NewPassword.Text == ConfirmPassword.Text)
                {
                    element.SelectSingleNode("Password").InnerText = currentPassword.Text;
                    element.SelectSingleNode("Password").InnerText = NewPassword.Text;
                    xml1.Save("UserInfo.xml");
                    this.Close();
                }
            }



        }





    }



    }
           
            

   