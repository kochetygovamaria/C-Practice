﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project
{
   public class Users: Person
    {
        public String UserName
        {
            get; set;
        }
        public String Password
        {
            get; set;
        }
        public DateTime DateOfBirth { get; set; }
        public String Nationality { get; set; }
        public String Passport { get; set; }
        public String Address { get; set; }
        public double Phone { get; set; }
        public String AccessPoint
        {
            get; set;
        }


        public Users()
        { }

        public void addUser( string UserName, string Password,string firstname, string lastname,DateTime DateOfBirth, string Nationality,string Passport ,string Address, double Phone, string AccessPoint)
        {
            this.UserName = UserName;
            this.Password = Password;
            FirstName= firstname ;
            LastName = lastname;
            this.DateOfBirth = DateOfBirth;
            this.Nationality = Nationality;
            this.Passport = Passport;
            this.Address = Address;
            this.Phone = Phone;
            this.AccessPoint = AccessPoint;
            

        }

    }
}
