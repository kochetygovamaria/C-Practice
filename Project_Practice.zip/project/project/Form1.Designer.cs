﻿namespace project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.SingINbt = new System.Windows.Forms.Button();
            this.UserID = new System.Windows.Forms.TextBox();
            this.PasswordID = new System.Windows.Forms.TextBox();
            this.userName = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.Label();
            this.CreateAccount = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // SingINbt
            // 
            this.SingINbt.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.SingINbt.Location = new System.Drawing.Point(165, 262);
            this.SingINbt.Name = "SingINbt";
            this.SingINbt.Size = new System.Drawing.Size(75, 23);
            this.SingINbt.TabIndex = 0;
            this.SingINbt.Text = "Sign In";
            this.SingINbt.UseVisualStyleBackColor = false;
            this.SingINbt.Click += new System.EventHandler(this.SingINbt_Click);
            // 
            // UserID
            // 
            this.UserID.Location = new System.Drawing.Point(186, 158);
            this.UserID.Name = "UserID";
            this.UserID.Size = new System.Drawing.Size(100, 20);
            this.UserID.TabIndex = 1;
            // 
            // PasswordID
            // 
            this.PasswordID.Location = new System.Drawing.Point(186, 204);
            this.PasswordID.Name = "PasswordID";
            this.PasswordID.Size = new System.Drawing.Size(100, 20);
            this.PasswordID.TabIndex = 2;
            // 
            // userName
            // 
            this.userName.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.userName.Location = new System.Drawing.Point(82, 158);
            this.userName.Margin = new System.Windows.Forms.Padding(3);
            this.userName.Name = "userName";
            this.userName.Padding = new System.Windows.Forms.Padding(3);
            this.userName.Size = new System.Drawing.Size(75, 20);
            this.userName.TabIndex = 3;
            this.userName.Text = "User Name";
            this.userName.Click += new System.EventHandler(this.label1_Click);
            // 
            // password
            // 
            this.password.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.password.Location = new System.Drawing.Point(82, 204);
            this.password.Margin = new System.Windows.Forms.Padding(3);
            this.password.Name = "password";
            this.password.Padding = new System.Windows.Forms.Padding(3);
            this.password.Size = new System.Drawing.Size(75, 20);
            this.password.TabIndex = 4;
            this.password.Text = "Password";
            // 
            // CreateAccount
            // 
            this.CreateAccount.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.CreateAccount.Location = new System.Drawing.Point(260, 262);
            this.CreateAccount.Name = "CreateAccount";
            this.CreateAccount.Size = new System.Drawing.Size(75, 23);
            this.CreateAccount.TabIndex = 5;
            this.CreateAccount.Text = "Create Account";
            this.CreateAccount.UseVisualStyleBackColor = false;
            this.CreateAccount.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(484, 381);
            this.Controls.Add(this.CreateAccount);
            this.Controls.Add(this.password);
            this.Controls.Add(this.userName);
            this.Controls.Add(this.PasswordID);
            this.Controls.Add(this.UserID);
            this.Controls.Add(this.SingINbt);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button SingINbt;
        private System.Windows.Forms.TextBox UserID;
        private System.Windows.Forms.TextBox PasswordID;
        private System.Windows.Forms.Label userName;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Button CreateAccount;
    }
}

