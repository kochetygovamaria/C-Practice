﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace project
{
    public static class Helper
    {
       /* public static BindingList<Users> LoadUsers(string path)
        {
            BindingList<Users> users = new BindingList<Users>();
            XmlDocument us = new XmlDocument();
            us.Load("UserInfo.xml");
            foreach (XmlNode node in us.DocumentElement.ChildNodes) { 
                string UserName = node.ChildNodes[0].InnerText;
                string Password= node.ChildNodes[1].InnerText;
                string FirstName = node.ChildNodes[2].InnerText;
                string LastName = node.ChildNodes[3].InnerText;
                string DateOfBirth = node.ChildNodes[4].InnerText;
                string Nationality = node.ChildNodes[5].InnerText;
                string Passort = node.ChildNodes[6].InnerText;
                string Address = node.ChildNodes[7].InnerText;
                string phone= node.ChildNodes[8].InnerText;
                string AccessPoint= node.ChildNodes[9].InnerText;

                Users user = new Users();
                DateTime oDate = Convert.ToDateTime(DateOfBirth);
                double Phone = Convert.ToDouble(phone);
                user.addUser(UserName,Password,FirstName,LastName,oDate,Nationality,Passort,Address,Phone,AccessPoint);

                

              users.Add(user);
            }
            return users;

        }*/
    }
}
