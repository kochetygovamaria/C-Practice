﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace project
{
    public partial class UpdatePassword : Form
    {
        internal Form2 form2;
        
        public UpdatePassword()
        {
            InitializeComponent();
        }

        private void UpdatePassword_Load(object sender, EventArgs e)
        {

        }

        private void Save_Click(object sender, EventArgs e)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load("UserInfo.xml");

            foreach (XmlNode node in doc.SelectNodes("//UserInfo"))
            {
                
                String Currentpassword = node.SelectSingleNode("Password").InnerText;

                if (Currentpassword == currentPassword.Text)
                {
                    if (NewPassword.Text == ConfirmPassword.Text)
                    {
                        doc.SelectSingleNode("//UsersInfo/UserInfo/Password").InnerText = NewPassword.Text;
                        this.Close();

                    }
                }

           

                }
           
            

        }
    }
}
