﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project
{
   public class Users: Person
    {
        public String UserName
        {
            get; set;
        }
        public String Password
        {
            get; set;
        }
        private DateTime DateOfBirth { get; set; }
        private String Nationality { get; set; }
        private String Passport { get; set; }
    private String Address { get; set; }
        private double Phone { get; set; }
        public String AccessPoint
        {
            get; set;
        }


        public Users()
        { }

        public void addUser( string UserName, string Password,string firstname, string lastname,DateTime DateOfBirth, string Nationality,string Passort ,string Address, double Phone, string Accesspoint)
        {
            this.UserName = UserName;
            this.Password = Password;
            FirstName= firstname ;
            LastName = lastname;
            this.DateOfBirth = DateOfBirth;
            this.Nationality = Nationality;
            this.Passport = Passport;

            this.Address = Address;
            this.Phone = Phone;
            this.AccessPoint = AccessPoint;
            

        }

    }
}
